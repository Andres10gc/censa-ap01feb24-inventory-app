<?php

use Illuminate\Support\Facades\Route;

Route::inertia('/', 'login')->name('login');