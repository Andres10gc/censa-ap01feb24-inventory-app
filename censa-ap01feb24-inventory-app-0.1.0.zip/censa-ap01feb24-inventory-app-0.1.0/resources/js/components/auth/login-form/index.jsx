export default function LoginForm() {
    return (
        <section>
            <h1>iniciar sesión</h1>
            <form></form>
        </section>
    )
}