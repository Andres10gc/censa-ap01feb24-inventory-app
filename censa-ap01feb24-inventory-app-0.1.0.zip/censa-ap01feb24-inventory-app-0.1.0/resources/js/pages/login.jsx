export default function Login() {
    return <h1>hola mundo.</h1>
}